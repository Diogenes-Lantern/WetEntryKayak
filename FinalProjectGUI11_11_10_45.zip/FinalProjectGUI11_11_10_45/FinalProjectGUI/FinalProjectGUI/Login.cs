﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProjectGUI
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home ho = new Home();
            ho.ShowDialog();
        }

        private void lblClickHere_Click(object sender, EventArgs e)
        {
            this.Hide();
            Create_Account ca = new Create_Account();
            ca.ShowDialog();
        }

        private void btnForgotPassword_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Contact us for further assistance.");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home ho = new Home();
            ho.ShowDialog();
        }
    }
}
