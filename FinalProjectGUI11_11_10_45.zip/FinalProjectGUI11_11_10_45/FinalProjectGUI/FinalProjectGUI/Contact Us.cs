﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProjectGUI
{
    public partial class Contact_Us : Form
    {
        public Contact_Us()
        {
            InitializeComponent();
        }

        private void checkoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Check_Out co = new Check_Out();
            co.ShowDialog();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void allToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Shop_All nk = new Shop_All();
            nk.ShowDialog();
        }

        private void newKayaksToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            New_Kayaks nk = new New_Kayaks();
            nk.ShowDialog();
        }

        private void gearAndAccToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Gear_and_Accessories gaa = new Gear_and_Accessories();
            gaa.ShowDialog();
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            About_Us au = new About_Us();
            au.ShowDialog();
        }

        private void contactUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The staff has been notified and will be reaching to you within the next 24 hours.");
        }
    }
}
