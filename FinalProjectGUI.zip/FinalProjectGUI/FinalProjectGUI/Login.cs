﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace FinalProjectGUI
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnSignIn_Click(object sender, EventArgs e)
        {

            try
            {



                if (radioCustomer.Checked == true)
                {
                    //sql connection//
                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = "Data source=essql1.walton.uark.edu;" +
                        "Initial Catalog=PROJECTF2027;" +
                        "USER ID=PROJECTF2027;Password=SH93ack$";

                    con.Open();

                    string password = txtPassword.Text;
                    SqlCommand cmd = new SqlCommand("select User_ID,Password from UserID_Password where User_ID='" +
                        txtUsername.Text + "'and Password='" + txtPassword.Text + "'", con);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Login sucess. Welcome to your account.");
                        this.Hide();
                        Home ho = new Home();
                        ho.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Invalid login please check username and password");
                    }
                    con.Close();
                }

                /////////
                else if (radioEmployee.Checked == true)
                {
                    //sql connection//
                    SqlConnection con = new SqlConnection();
                    con.ConnectionString = "Data source=essql1.walton.uark.edu;" +
                        "Initial Catalog=PROJECTF2027;" +
                        "USER ID=PROJECTF2027;Password=SH93ack$";
                    con.Open();

                    string password = txtPassword.Text;
                    SqlCommand cmd = new SqlCommand("select User_ID,Password from UserID_Password where User_ID='" +
                        txtUsername.Text + "'and Password='" + txtPassword.Text + "'", con);


                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {
                        MessageBox.Show("Login sucess. Welcome to your account.");
                        this.Hide();
                        Home ho = new Home();
                        ho.ShowDialog();
                    }
                    else
                    {
                        MessageBox.Show("Invalid login please check username and password");
                    }
                    con.Close();
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error incorrect see this: " + ex);
            }
        }




            private void lblClickHere_Click(object sender, EventArgs e)
        {
            this.Hide();
            Create_Account ca = new Create_Account();
            ca.ShowDialog();
        }

        private void btnForgotPassword_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Contact us for further assistance.");
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Home ho = new Home();
            ho.ShowDialog();
        }
    }
}
